const mongoose = require('mongoose');

const NotesSchema = new mongoose.Schema({
    noteTitle: {
        type: String,
        required: true,
        trim: true,
        lowercase: true
    },
    noteDescription: {
        type: String,
        required: true,
        trim: true,
        lowercase: true
    },
    priority: {
        type: Number,
        default: 0.0,
    },
    dateAdded:{
        type: Date,
        default: Date.now()
    },
    dateUpdated:{
        type: Date,
        default: Date.now()
    }
});

const Notes = mongoose.model("Note", NotesSchema);
module.exports = Notes;
//TODO - Create Note Schema here having fields
//      - noteTitle
//      - noteDescription
//      - priority (Value can be HIGH, LOW or MEDUIM)
//      - dateAdded
//      - dateUpdated