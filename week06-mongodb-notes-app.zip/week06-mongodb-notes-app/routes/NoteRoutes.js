const  express = require('express');
const NotesModel = require('../models/NotesModel')
const app = express();

//TODO - Create a new Note

//http://mongoosejs.com/docs/api.html#document_Document-save
app.post('/notes',async (req, res) => {

        const notes = new NotesModel(req.body);
        try {
            await notes.save();
            res.send(notes);
        } catch (err) {
            res.status(500).send(err);
        }

    //TODO - Write your code here to save the note
});

//TODO - Retrieve all Notes
//http://mongoosejs.com/docs/api.html#find_find
app.get('/notes',async (req, res) => {
        const notes = await NotesModel.find({});
        try {
            res.send(notes);
        } catch (err) {
            res.status(500).send(err);
        }

    //TODO - Write your code here to returns all note
});

//TODO - Retrieve a single Note with noteId
//http://mongoosejs.com/docs/api.html#findbyid_findById
app.get('/notes/:noteId',async (req, res) => {

    try {
            const note = await NotesModel.findById(req.params.id)

            if (!note) res.status(404).send("No item found")
            res.status(200).send()
        } catch (err) {
            res.status(500).send(err)
        }

    //TODO - Write your code here to return onlt one note using noteid
});

//TODO - Update a Note with noteId
//http://mongoosejs.com/docs/api.html#findbyidandupdate_findByIdAndUpdate
app.put('/notes/:noteId', async (req, res) => {
    //const notes = await NotesModel.find({});
    try {
        await NotesModel.findByIdAndDelete(req.params.id,req.body)
        await NotesModel.save();
        res.send(notes)

        if (!note) res.status(404).send("No item found")
        res.status(200).send()
    } catch (err) {
        res.status(500).send(err)
    }
    //TODO - Write your code here to update the note using noteid
});

//TODO - Delete a Note with noteId
//http://mongoosejs.com/docs/api.html#findbyidandremove_findByIdAndRemove
app.delete('/notes/:noteId',async (req, res) => {
    try {
        const note = await NotesModel.findByIdAndDelete(req.params.id)

        if (!note) res.status(404).send("No item found")
        res.status(200).send()
    } catch (err) {
        res.status(500).send(err)
    }
    //TODO - Write your code here to delete the note using noteid
})

module.exports = app;
